T-Net 6.11.0: experimental adapter-switching and Wi-Fi signal release.
Compiled for Windows with .NET Framework WinForms.
Use T-Net's in-app Check for updates to apply to the current installation,
preserving the existing local usage history and user settings.
The existing installer/updater handles the in-place update. Do not delete
your existing data or replace the %LOCALAPPDATA%\AirtelDataMonitor\data folder.
This update was compiled and exercised using simulated Windows adapters;
physical Intel AX200 and Realtek RTL8188FTV switching MUST be tested
on the user's Windows laptop. The executable needs monitor.ps1 beside it.